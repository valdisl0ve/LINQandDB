﻿namespace LINQandDB
{
    public class Role
    {
        public string roleName { get; set; }
    }
}