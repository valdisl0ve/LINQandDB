﻿namespace LINQandDB
{
    public class Account_Role
    {
        public string account { get; set; }
        public string Role { get; set; }
    }
}