﻿namespace LINQandDB
{
    public class Account
    {
        public string login { get; set; }
        public string password { get; set; }
        public bool isActive { get; set; }
    }
}