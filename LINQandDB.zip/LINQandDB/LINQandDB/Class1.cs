﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using MySql.Data.MySqlClient;

namespace LINQandDB
{
    public class Class1
    {
        const string connection = "";
        MySqlConnection db = new MySqlConnection(connection); 
        
        public void ImportFromDB()
        {
            User user = new User();
            db = new MySqlConnection(connection);
            db.Open();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            MySqlCommand command = new MySqlCommand($"SELECT * from FROM table_USER", db);
            adapter.SelectCommand = command;
            adapter.Fill(table);

            foreach (var item in (IEnumerable) table)
            {
                user.name = 
            }
            
            
            
            
            
            db.Close();
        }
        
    }
}