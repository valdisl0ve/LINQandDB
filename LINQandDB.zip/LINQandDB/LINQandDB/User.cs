﻿namespace LINQandDB
{
    public class User
    {
        public string name { get; set; }
        public string surName { get; set; }
        public string contact { get; set; }
    }
}